Arrays

functionality is similar to Java's ArrayLists (https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html)